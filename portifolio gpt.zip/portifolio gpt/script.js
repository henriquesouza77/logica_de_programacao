/* =====================================================
   CURSOR EFFECT
===================================================== */

const cursor = document.querySelector('.cursor');
const cursorBlur = document.querySelector('.cursor-blur');

window.addEventListener('mousemove', (e) => {

  cursor.style.left = e.clientX + 'px';
  cursor.style.top = e.clientY + 'px';

  cursorBlur.style.left = e.clientX - 200 + 'px';
  cursorBlur.style.top = e.clientY - 200 + 'px';

});

/* =====================================================
   TYPING EFFECT
===================================================== */

const typingElement = document.getElementById('typing');

const words = [
  'UI Futurista',
  'Experiências Imersivas',
  'Frontend Premium',
  'Motion Design Cinematográfico'
];

let wordIndex = 0;
let letterIndex = 0;
let currentWord = '';
let isDeleting = false;

function typeEffect(){

  currentWord = words[wordIndex];

  if(!isDeleting){
    typingElement.textContent = currentWord.substring(0, letterIndex + 1);
    letterIndex++;

    if(letterIndex === currentWord.length){
      isDeleting = true;
      setTimeout(typeEffect, 1500);
      return;
    }
  }

  else{
    typingElement.textContent = currentWord.substring(0, letterIndex - 1);
    letterIndex--;

    if(letterIndex === 0){
      isDeleting = false;
      wordIndex = (wordIndex + 1) % words.length;
    }
  }

  setTimeout(typeEffect, isDeleting ? 50 : 100);
}

typeEffect();

/* =====================================================
   SCROLL REVEAL
===================================================== */

const reveals = document.querySelectorAll('.reveal');

function revealOnScroll(){

  reveals.forEach((element) => {

    const windowHeight = window.innerHeight;
    const revealTop = element.getBoundingClientRect().top;

    if(revealTop < windowHeight - 100){
      element.classList.add('active');
    }

  });

}

window.addEventListener('scroll', revealOnScroll);
revealOnScroll();

/* =====================================================
   PARTICLES
===================================================== */

const particlesContainer = document.getElementById('particles');

for(let i = 0; i < 60; i++){

  const particle = document.createElement('span');

  particle.style.width = Math.random() * 4 + 'px';
  particle.style.height = particle.style.width;

  particle.style.left = Math.random() * window.innerWidth + 'px';
  particle.style.top = Math.random() * window.innerHeight + 'px';

  particle.style.animationDuration = (Math.random() * 10 + 5) + 's';
  particle.style.animationDelay = Math.random() * 5 + 's';

  particlesContainer.appendChild(particle);
}

/* =====================================================
   PARTICLES STYLE
===================================================== */

const style = document.createElement('style');
style.innerHTML = `

#particles{
  position:fixed;
  width:100%;
  height:100%;
  overflow:hidden;
  top:0;
  left:0;
  z-index:-2;
}

#particles span{
  position:absolute;
  background:rgba(255,255,255,0.7);
  border-radius:50%;
  animation:particleAnimation linear infinite;
}

@keyframes particleAnimation{

  0%{
    transform:translateY(0px) scale(1);
    opacity:0;
  }

  10%{
    opacity:1;
  }

  100%{
    transform:translateY(-1000px) scale(0);
    opacity:0;
  }

}
`;

document.head.appendChild(style);

/* =====================================================
   3D HOVER EFFECT
===================================================== */

const cards = document.querySelectorAll('.glass-card, .about-card, .service-card');

cards.forEach(card => {

  card.addEventListener('mousemove', (e) => {

    const rect = card.getBoundingClientRect();

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateX = ((y - centerY) / 18);
    const rotateY = ((centerX - x) / 18);

    card.style.transform = `
      perspective(1000px)
      rotateX(${rotateX}deg)
      rotateY(${rotateY}deg)
      scale(1.03)
    `;

  });

  card.addEventListener('mouseleave', () => {

    card.style.transform = `
      perspective(1000px)
      rotateX(0deg)
      rotateY(0deg)
      scale(1)
    `;

  });

});

/* =====================================================
   HEADER SCROLL EFFECT
===================================================== */

const header = document.querySelector('header');

window.addEventListener('scroll', () => {

  if(window.scrollY > 50){
    header.style.background = 'rgba(0,0,0,0.45)';
    header.style.borderBottom = '1px solid rgba(255,255,255,0.12)';
  }

  else{
    header.style.background = 'rgba(255,255,255,0.03)';
  }

});

/* =====================================================
   SMOOTH BUTTON INTERACTION
===================================================== */

const buttons = document.querySelectorAll('button');

buttons.forEach(button => {

  button.addEventListener('mouseenter', () => {
    button.style.transform = 'translateY(-4px) scale(1.03)';
  });

  button.addEventListener('mouseleave', () => {
    button.style.transform = 'translateY(0px) scale(1)';
  });

});
